package com.cg.service;

import java.util.List;

import com.cg.models.Product;

public interface IProductService {

	public Product findByCode(String code);
	public void saveproduct(Product product);
	public List<Product> findAll();
	public void deleteproduct(String code);
	public void updateproduct(Product product);
}
